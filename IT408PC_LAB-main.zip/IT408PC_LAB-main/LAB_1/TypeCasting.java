 class First{
   public static void main(String[] args){
        int x=10;
      	double y=x;
      	float z=(float)y;
      	long num=400;
      	int a=(int)num;
        System.out.println(x);
        System.out.println(y);
        System.out.println(num);
        System.out.println(z);
        System.out.println(a);
    }
}
