public class L3P2{
	public static void main(String... args){
		Dog d = new Dog();
		d.makeSound();
	}
}