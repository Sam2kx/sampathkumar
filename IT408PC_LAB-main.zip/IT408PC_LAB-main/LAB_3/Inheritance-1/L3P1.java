public class L3P1{
	public static void main(String...args){
		B b = new B();
		b.display();
		System.out.println(b.show());
		b.pearl();
		b.displayA();
	}
}
