class Tiger extends Animal1{
	public void sound(){
		System.out.println("Tiger Roaring...");
	}
}