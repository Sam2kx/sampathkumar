class L3P3{
	public static void main(String...args){
		Lion l = new Lion();
		l.sound();
		Tiger t = new Tiger();
		t.sound();
	}
}