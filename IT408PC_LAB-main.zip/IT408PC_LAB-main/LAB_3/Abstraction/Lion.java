class Lion extends Animal1{
	public void sound(){
		System.out.println("Lion Roaring...");
	}
}