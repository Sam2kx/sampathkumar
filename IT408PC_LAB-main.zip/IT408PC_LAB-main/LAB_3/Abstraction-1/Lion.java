abstract class Lion extends Animal1{
	abstract void behave();
	public void sound(){
		System.out.println("Lion Roaring...");
	}
}