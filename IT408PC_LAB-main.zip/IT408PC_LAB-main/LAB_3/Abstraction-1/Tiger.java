class Tiger extends Lion{
	public void behave(){
		System.out.println("Peek");
	}
	public void sound(){
		System.out.println("Tiger Roaring...");
	}
}