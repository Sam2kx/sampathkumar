class L3P3{
	public static void main(String...args){
		Tiger t = new Tiger();
		t.behave();
		t.sound();
	}
}