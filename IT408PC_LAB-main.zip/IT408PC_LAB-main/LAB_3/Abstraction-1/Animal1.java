abstract class Animal1{
	abstract void sound();
}